# ParishTax

Native Android / Kotlin / Jetpack Compose / Material 3 / Room / StateFlow / Navigation Compose / Coroutines.

**Application ID:** `com.aliparish.parishtax`

## What this project is

This is the native Android successor architecture for the uploaded `ParishTax_WebApp_v0_5.html`. The HTML version is preserved conceptually, but the Android implementation replaces `localStorage` with Room and introduces versioned tax data, encrypted database storage, import validation, source tracking, and testable tax-engine logic.

The uploaded web version already had year-separated UI, client/case/expense screens, an INTA search area, a legal-library area, JSON backup, and a warning not to fabricate missing official INTA data. Those principles were retained. The uploaded version also contained hard-coded demo exemptions and a fixed 15% tax rate; the native engine intentionally does **not** treat those as authoritative. fileciteturn0file0L30-L35 fileciteturn0file0L130-L158

## Toolchain

- Android Gradle Plugin 9.4.0
- Gradle 9.6
- JDK 17
- Kotlin compiler integration supplied by AGP 9.4 / KGP 2.2.10
- Compose BOM 2026.09.00
- Room 2.8.5
- Navigation Compose 2.10.2
- SQLCipher for Android 4.17.0
- minSdk 24 / targetSdk 37

The versions were selected against the September 2026 Android release notes. AGP 9.4.0 uses Gradle 9.6.0 and JDK 17; Compose's current stable BOM is 2026.09.00; Room's stable release is 2.8.5. See official docs in the delivery notes.

## Build

1. Install Android Studio with Android SDK Platform 37 and Build Tools 36.0.0.
2. Install JDK 17.
3. Open this folder in Android Studio.
4. Let Gradle sync.
5. Run `app` on an Android 7.0+ device/emulator.
6. For APK: **Build > Build APK(s)**.
7. Debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk` after a successful build.

A Gradle wrapper properties file is included. The wrapper JAR could not be generated in this environment because the environment did not contain Gradle or the Android SDK and outbound package downloads were unavailable.

## Database

Room schema version 1 contains:

Client, TaxYear, Income, Expense, TaxCase, IntaCode, TaxRule, Circular, Judgment, DefenseDocument, Deadline, SourceDocument, Calculation, AppSettings.

The database is encrypted with SQLCipher. The database passphrase is randomly generated once and wrapped by an Android Keystore AES-GCM master key.

## Tax rules and data safety

There is intentionally no fallback to another tax year. If a required exemption, tax rate, rule version, or INTA coefficient is absent for the selected year, the calculation returns `MissingData` instead of using another year's value.

Every legal/INTA record has source/status/version fields. `DEMO` and `UNVERIFIED` are never equivalent to `VERIFIED`.

## Official-data import

`ImportPipeline` is the boundary for the planned official-data workflow:

Import -> Parse -> Validate -> Deduplicate -> Version -> Review -> Publish

The validator rejects INTA records without a source or with non-verified status, and rejects legal rules without source/version/text.

The current backup importer supports ParishTax JSON backups. Official PDF/Excel parsing is intentionally not claimed as complete because no official source files were supplied with this delivery. Add parsers/adapters under `importer/` once official files are available.

## AI Tax Assistant

The UI currently performs local rule retrieval. A provider-neutral AI boundary should be connected later. The AI layer must receive only retrieved source chunks and must cite source IDs/URLs in every generated legal assertion. If no source is retrieved, the UI must say `منبع معتبر پیدا نشد`.

No API key is bundled in the project.

## Sample data

Only a small demo seed is included. Example `3200030 / 1403 / 25%` is explicitly marked `DEMO` and sourced as user-provided sample content from the uploaded v0.5 web app. It is not asserted to be an official current coefficient.

## Still requires official import

- Complete official INTA datasets for each tax year.
- Official year-specific Article 101 exemption amounts.
- Official year-specific tax-rate rules.
- Full official law/circular/judgment text and metadata.
- Official source URLs/document IDs and verification workflow.
- Production AI provider credentials and a server-side key-management strategy, if cloud AI is desired.
- Official PDF/Excel ingestion adapters.

## Testing

`TaxEngineTest` verifies:
- missing exemption blocks calculation;
- missing tax rate blocks calculation;
- only accepted expenses are used in actual-cost mode;
- actual expenses are not subtracted again in INTA mode.
