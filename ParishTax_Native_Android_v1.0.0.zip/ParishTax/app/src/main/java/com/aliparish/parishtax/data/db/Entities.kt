package com.aliparish.parishtax.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "clients", indices = [Index("nationalId"), Index("taxFileNumber")])
data class Client(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val nationalId: String = "",
    val economicNumber: String = "",
    val taxFileNumber: String = "",
    val phone: String = "",
    val taxpayerType: String = "حقیقی",
    val activity: String = "",
    val intaCode: String = "",
    val province: String = "",
    val city: String = "",
    val address: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "tax_years", primaryKeys = ["clientId", "year"])
data class TaxYear(
    val clientId: Long,
    val year: String,
    val ruleVersion: String = "",
    val exemptionAmount: Long? = null,
    val sourceId: Long? = null,
    val status: String = "MISSING"
)

@Entity(tableName = "incomes", indices = [Index("clientId", "year")])
data class Income(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientId: Long,
    val year: String,
    val title: String,
    val amount: Long,
    val sourceDocumentId: Long? = null,
    val notes: String = ""
)

@Entity(tableName = "expenses", indices = [Index("clientId", "year"), Index("category")])
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientId: Long,
    val year: String,
    val category: String,
    val amount: Long,
    val date: String = "",
    val description: String = "",
    val paymentMethod: String = "",
    val documentNumber: String = "",
    val invoiceId: String = "",
    val counterparty: String = "",
    val documentationStatus: String = "UNKNOWN",
    val acceptedStatus: String = "REVIEW",
    val notes: String = ""
)

@Entity(tableName = "tax_cases", indices = [Index("clientId", "year"), Index("stage")])
data class TaxCase(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientId: Long,
    val year: String,
    val title: String,
    val issue: String = "",
    val declaredAmount: Long = 0,
    val assessedAmount: Long = 0,
    val disputedAmount: Long = 0,
    val stage: String = "ثبت و نام‌نویسی",
    val importantDatesJson: String = "{}",
    val legalDeadline: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "inta_codes", indices = [Index(value = ["code", "year"], unique = true), Index("year"), Index("title")])
data class IntaCode(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val title: String,
    val activityType: String = "",
    val groupName: String = "",
    val subgroupName: String = "",
    val year: String,
    val activityPercent: Double? = null,
    val profitPercent: Double? = null,
    val description: String = "",
    val source: String = "",
    val sourceUrl: String = "",
    val issueDate: String = "",
    val effectiveFrom: String = "",
    val effectiveTo: String = "",
    val status: String = "UNVERIFIED",
    val isDemo: Boolean = false,
    val documentId: String = ""
)

@Entity(tableName = "tax_rules", indices = [Index("reference")])
data class TaxRule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reference: String,
    val title: String,
    val documentType: String = "قانون",
    val article: String = "",
    val paragraph: String = "",
    val note: String = "",
    val applicableTaxYears: String = "",
    val approvalDate: String = "",
    val effectiveDate: String = "",
    val status: String = "UNVERIFIED",
    val version: String = "",
    val effectiveFrom: String = "",
    val effectiveTo: String = "",
    val text: String = "",
    val source: String = "",
    val sourceUrl: String = "",
    val issuingAuthority: String = "",
    val relatedTopics: String = "",
    val ruleType: String = "",
    val numericValue: Double? = null,
    val isDemo: Boolean = false
)

@Entity(tableName = "circulars", indices = [Index("number"), Index("year")])
data class Circular(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val number: String,
    val title: String,
    val year: String = "",
    val issueDate: String = "",
    val effectiveDate: String = "",
    val text: String = "",
    val source: String = "",
    val sourceUrl: String = "",
    val status: String = "UNVERIFIED"
)

@Entity(tableName = "judgments", indices = [Index("number")])
data class Judgment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val number: String,
    val title: String,
    val court: String = "",
    val issueDate: String = "",
    val text: String = "",
    val source: String = "",
    val sourceUrl: String = "",
    val status: String = "UNVERIFIED"
)

@Entity(tableName = "defense_documents", indices = [Index("caseId")])
data class DefenseDocument(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val caseId: Long,
    val documentType: String,
    val title: String,
    val body: String,
    val sourceRefs: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "deadlines", indices = [Index("caseId"), Index("dueDate")])
data class Deadline(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val caseId: Long? = null,
    val clientId: Long? = null,
    val title: String,
    val dueDate: String,
    val status: String = "OPEN",
    val notes: String = ""
)

@Entity(tableName = "source_documents", indices = [Index("documentId")])
data class SourceDocument(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val documentId: String,
    val title: String,
    val documentType: String,
    val source: String,
    val sourceUrl: String = "",
    val issueDate: String = "",
    val checksum: String = "",
    val verified: Boolean = false,
    val importedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "calculations", indices = [Index("clientId", "year")])
data class Calculation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientId: Long,
    val year: String,
    val mode: String,
    val revenue: Long,
    val acceptedExpenses: Long,
    val exemption: Long,
    val taxableIncome: Long,
    val taxAmount: Long,
    val ruleVersion: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "app_settings")
data class AppSettings(
    @PrimaryKey val key: String,
    val value: String
)
