package com.aliparish.parishtax.security

import android.content.Context
import java.security.MessageDigest

class SecurityPreferences(context: Context) {
    private val p=context.getSharedPreferences("security_preferences",Context.MODE_PRIVATE)
    var biometricEnabled:Boolean get()=p.getBoolean("biometric",false) set(v){p.edit().putBoolean("biometric",v).apply()}
    fun setPin(pin:String){p.edit().putString("pin_hash",hash(pin)).apply()}
    fun hasPin()=p.contains("pin_hash")
    fun verifyPin(pin:String)=p.getString("pin_hash","")==hash(pin)
    private fun hash(s:String)=MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString(""){"%02x".format(it)}
}
