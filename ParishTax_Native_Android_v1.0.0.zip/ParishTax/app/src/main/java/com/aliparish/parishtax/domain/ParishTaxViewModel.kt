package com.aliparish.parishtax.domain

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aliparish.parishtax.ParishTaxApplication
import com.aliparish.parishtax.data.db.*
import com.aliparish.parishtax.importer.BackupService
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ParishTaxViewModel(app: Application): AndroidViewModel(app) {
    private val db=(app as ParishTaxApplication).database
    val clients=db.clientDao().observeAll().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val expenses=db.expenseDao().observeAll().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val cases=db.taxCaseDao().observeAll().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val inta=db.intaDao().observeAll().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val rules=db.ruleDao().observeAll().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val deadlines=db.deadlineDao().observeOpen().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    private val engine=TaxEngine()
    private val backup=BackupService(db)

    fun addClient(c:Client, onDone:(Long)->Unit={})=viewModelScope.launch{onDone(db.clientDao().insert(c))}
    fun addExpense(e:Expense)=viewModelScope.launch{db.expenseDao().insert(e)}
    fun addCase(c:TaxCase)=viewModelScope.launch{db.taxCaseDao().insert(c)}
    fun deleteClient(c:Client)=viewModelScope.launch{db.clientDao().delete(c)}
    fun deleteExpense(e:Expense)=viewModelScope.launch{db.expenseDao().delete(e)}
    fun deleteCase(c:TaxCase)=viewModelScope.launch{db.taxCaseDao().delete(c)}
    suspend fun searchRules(q:String)=db.ruleDao().search(q)
    suspend fun searchInta(year:String,q:String)=db.intaDao().search(year,q)
    suspend fun calculate(clientId:Long,year:String,mode:String,revenue:Long):CalculationResult {
        val client=db.clientDao().get(clientId) ?: return CalculationResult.MissingData("مشتری پیدا نشد.")
        val inta=db.intaDao().search(year,client.intaCode).firstOrNull()
        val expenses=db.expenseDao().forCalculation(clientId,year)
        val taxYear=db.taxYearDao().observeForClient(clientId).first().firstOrNull{it.year==year}
        val ruleVersion=taxYear?.ruleVersion?.takeIf{it.isNotBlank()}
        val exemption=taxYear?.exemptionAmount
        val rateRule=db.ruleDao().search("$year نرخ مالیات").firstOrNull{it.ruleType=="TAX_RATE" && it.applicableTaxYears.split(',').map(String::trim).contains(year)}
        return engine.calculate(year,revenue,mode,inta,expenses,exemption,ruleVersion,rateRule?.numericValue)
    }
    suspend fun exportJson()=backup.exportJson()
    suspend fun importJson(text:String)=backup.importJson(text)
}
