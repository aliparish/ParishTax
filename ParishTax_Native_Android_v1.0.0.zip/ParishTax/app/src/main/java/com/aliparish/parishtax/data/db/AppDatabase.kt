package com.aliparish.parishtax.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory

@Database(
    entities = [Client::class, TaxYear::class, Income::class, Expense::class, TaxCase::class,
        IntaCode::class, TaxRule::class, Circular::class, Judgment::class, DefenseDocument::class,
        Deadline::class, SourceDocument::class, Calculation::class, AppSettings::class],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun clientDao(): ClientDao
    abstract fun taxYearDao(): TaxYearDao
    abstract fun incomeDao(): IncomeDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun taxCaseDao(): TaxCaseDao
    abstract fun intaDao(): IntaDao
    abstract fun ruleDao(): RuleDao
    abstract fun circularDao(): CircularDao
    abstract fun judgmentDao(): JudgmentDao
    abstract fun defenseDao(): DefenseDao
    abstract fun deadlineDao(): DeadlineDao
    abstract fun sourceDocumentDao(): SourceDocumentDao
    abstract fun calculationDao(): CalculationDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        fun create(context: Context, passphrase: ByteArray): AppDatabase {
            val factory = SupportOpenHelperFactory(passphrase, null, true)
            return Room.databaseBuilder(context, AppDatabase::class.java, "parishtax.db")
                .openHelperFactory(factory)
                .fallbackToDestructiveMigrationOnDowngrade()
                .build()
        }
    }
}
