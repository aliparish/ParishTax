package com.aliparish.parishtax

import android.app.Application
import com.aliparish.parishtax.data.db.AppDatabase
import com.aliparish.parishtax.security.KeyStoreManager

class ParishTaxApplication : Application() {
    lateinit var database: AppDatabase
        private set

    override fun onCreate() {
        super.onCreate()
        System.loadLibrary("sqlcipher")
        database = AppDatabase.create(this, KeyStoreManager(this).databasePassphrase())
        kotlinx.coroutines.runBlocking { com.aliparish.parishtax.data.db.SeedData.seedIfEmpty(this@ParishTaxApplication, database) }
    }
}
