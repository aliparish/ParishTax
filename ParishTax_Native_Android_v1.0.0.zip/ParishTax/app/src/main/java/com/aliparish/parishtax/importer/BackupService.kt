package com.aliparish.parishtax.importer

import com.aliparish.parishtax.data.db.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

@Serializable data class Backup<T>(val schema:Int, val exportedAt:Long, val data:T)
@Serializable data class CoreBackup(val clients:List<ClientDto>, val expenses:List<ExpenseDto>, val cases:List<CaseDto>, val inta:List<IntaDto>, val rules:List<RuleDto>)
@Serializable data class ClientDto(val id:Long,val name:String,val nationalId:String,val economicNumber:String,val taxFileNumber:String,val phone:String,val taxpayerType:String,val activity:String,val intaCode:String,val province:String,val city:String,val address:String,val notes:String,val createdAt:Long)
@Serializable data class ExpenseDto(val id:Long,val clientId:Long,val year:String,val category:String,val amount:Long,val date:String,val description:String,val paymentMethod:String,val documentNumber:String,val invoiceId:String,val counterparty:String,val documentationStatus:String,val acceptedStatus:String,val notes:String)
@Serializable data class CaseDto(val id:Long,val clientId:Long,val year:String,val title:String,val issue:String,val declaredAmount:Long,val assessedAmount:Long,val disputedAmount:Long,val stage:String,val importantDatesJson:String,val legalDeadline:String,val notes:String,val createdAt:Long)
@Serializable data class IntaDto(val id:Long,val code:String,val title:String,val activityType:String,val groupName:String,val subgroupName:String,val year:String,val activityPercent:Double?,val profitPercent:Double?,val description:String,val source:String,val sourceUrl:String,val issueDate:String,val effectiveFrom:String,val effectiveTo:String,val status:String,val isDemo:Boolean,val documentId:String)
@Serializable data class RuleDto(val id:Long,val reference:String,val title:String,val documentType:String,val article:String,val paragraph:String,val note:String,val applicableTaxYears:String,val approvalDate:String,val effectiveDate:String,val status:String,val version:String,val effectiveFrom:String,val effectiveTo:String,val text:String,val source:String,val sourceUrl:String,val issuingAuthority:String,val relatedTopics:String,val ruleType:String,val numericValue:Double?,val isDemo:Boolean)

class BackupService(private val db:AppDatabase) {
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }
    suspend fun exportJson():String {
        val payload=CoreBackup(
            db.clientDao().all().map{ClientDto(it.id,it.name,it.nationalId,it.economicNumber,it.taxFileNumber,it.phone,it.taxpayerType,it.activity,it.intaCode,it.province,it.city,it.address,it.notes,it.createdAt)},
            db.expenseDao().all().map{ExpenseDto(it.id,it.clientId,it.year,it.category,it.amount,it.date,it.description,it.paymentMethod,it.documentNumber,it.invoiceId,it.counterparty,it.documentationStatus,it.acceptedStatus,it.notes)},
            db.taxCaseDao().all().map{CaseDto(it.id,it.clientId,it.year,it.title,it.issue,it.declaredAmount,it.assessedAmount,it.disputedAmount,it.stage,it.importantDatesJson,it.legalDeadline,it.notes,it.createdAt)},
            db.intaDao().all().map{IntaDto(it.id,it.code,it.title,it.activityType,it.groupName,it.subgroupName,it.year,it.activityPercent,it.profitPercent,it.description,it.source,it.sourceUrl,it.issueDate,it.effectiveFrom,it.effectiveTo,it.status,it.isDemo,it.documentId)},
            db.ruleDao().all().map{RuleDto(it.id,it.reference,it.title,it.documentType,it.article,it.paragraph,it.note,it.applicableTaxYears,it.approvalDate,it.effectiveDate,it.status,it.version,it.effectiveFrom,it.effectiveTo,it.text,it.source,it.sourceUrl,it.issuingAuthority,it.relatedTopics,it.ruleType,it.numericValue,it.isDemo)}
        )
        return json.encodeToString(Backup(1,System.currentTimeMillis(),payload))
    }
    suspend fun importJson(text:String) {
        val b=json.decodeFromString<Backup<CoreBackup>>(text)
        require(b.schema==1) { "نسخه پشتیبان پشتیبانی نمی‌شود." }
        db.clientDao().insertAll(b.data.clients.map{Client(it.id,it.name,it.nationalId,it.economicNumber,it.taxFileNumber,it.phone,it.taxpayerType,it.activity,it.intaCode,it.province,it.city,it.address,it.notes,it.createdAt)})
        db.expenseDao().insertAll(b.data.expenses.map{Expense(it.id,it.clientId,it.year,it.category,it.amount,it.date,it.description,it.paymentMethod,it.documentNumber,it.invoiceId,it.counterparty,it.documentationStatus,it.acceptedStatus,it.notes)})
        db.taxCaseDao().insertAll(b.data.cases.map{TaxCase(it.id,it.clientId,it.year,it.title,it.issue,it.declaredAmount,it.assessedAmount,it.disputedAmount,it.stage,it.importantDatesJson,it.legalDeadline,it.notes,it.createdAt)})
        db.intaDao().upsertAll(b.data.inta.map{IntaCode(it.id,it.code,it.title,it.activityType,it.groupName,it.subgroupName,it.year,it.activityPercent,it.profitPercent,it.description,it.source,it.sourceUrl,it.issueDate,it.effectiveFrom,it.effectiveTo,it.status,it.isDemo,it.documentId)})
        db.ruleDao().upsertAll(b.data.rules.map{TaxRule(it.id,it.reference,it.title,it.documentType,it.article,it.paragraph,it.note,it.applicableTaxYears,it.approvalDate,it.effectiveDate,it.status,it.version,it.effectiveFrom,it.effectiveTo,it.text,it.source,it.sourceUrl,it.issuingAuthority,it.relatedTopics,it.ruleType,it.numericValue,it.isDemo)})
    }
}
