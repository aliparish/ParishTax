package com.aliparish.parishtax.data.db

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object SeedData {
    suspend fun seedIfEmpty(context: Context, db: AppDatabase) = withContext(Dispatchers.IO) {
        if (db.intaDao().all().isNotEmpty() || db.ruleDao().all().isNotEmpty()) return@withContext
        db.intaDao().upsertAll(
            listOf(
                IntaCode(code="3200030",title="آرایشگاه مردانه درجه دو و غیره",year="1403",profitPercent=25.0,source="DEMO / SAMPLE — based on uploaded ParishTax WebApp v0.5",status="DEMO",isDemo=true),
                IntaCode(code="3060030",title="کافی شاپ",year="1403",profitPercent=null,source="DEMO / SAMPLE — coefficient not verified",status="DEMO",isDemo=true),
                IntaCode(code="3060030",title="کافی شاپ",year="1404",profitPercent=null,source="No official source imported",status="MISSING",isDemo=true),
                IntaCode(code="3060030",title="کافی شاپ",year="1405",profitPercent=null,source="No official source imported",status="MISSING",isDemo=true)
            )
        )
        val demoRules=listOf(
            TaxRule(reference="ماده 147",title="هزینه‌های قابل قبول",documentType="قانون",text="هزینه باید در حدود متعارف، متکی به مدارک و منحصراً مربوط به تحصیل درآمد باشد.",relatedTopics="هزینه اجاره مدارک درآمد",status="DEMO",isDemo=true,source="DEMO / SAMPLE — uploaded WebApp v0.5"),
            TaxRule(reference="ماده 148",title="مصادیق هزینه‌های قابل قبول",documentType="قانون",text="مصادیق هزینه‌های قابل قبول طبق متن قانون و مقررات مرتبط بررسی می‌شوند.",relatedTopics="اجاره مواد اولیه حقوق آب برق تبلیغات تسهیلات",status="DEMO",isDemo=true,source="DEMO / SAMPLE — uploaded WebApp v0.5"),
            TaxRule(reference="ماده 238",title="اعتراض به برگ تشخیص",documentType="قانون",text="اعتراض و رسیدگی مجدد در چارچوب مقررات مربوط انجام می‌شود.",relatedTopics="اعتراض برگ تشخیص دفاع",status="DEMO",isDemo=true,source="DEMO / SAMPLE — uploaded WebApp v0.5")
        )
        db.ruleDao().upsertAll(demoRules)
    }
}
