package com.aliparish.parishtax.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao interface ClientDao {
    @Query("SELECT * FROM clients ORDER BY name") fun observeAll(): Flow<List<Client>>
    @Query("SELECT * FROM clients") suspend fun all(): List<Client>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun insertAll(items:List<Client>)
    @Query("SELECT * FROM clients WHERE id=:id LIMIT 1") suspend fun get(id: Long): Client?
    @Insert suspend fun insert(item: Client): Long
    @Update suspend fun update(item: Client)
    @Delete suspend fun delete(item: Client)
    @Query("SELECT COUNT(*) FROM clients") fun count(): Flow<Int>
}
@Dao interface TaxYearDao { @Query("SELECT * FROM tax_years WHERE clientId=:clientId ORDER BY year") fun observeForClient(clientId:Long): Flow<List<TaxYear>>; @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsert(item:TaxYear) }
@Dao interface IncomeDao { @Query("SELECT * FROM incomes WHERE clientId=:clientId AND year=:year ORDER BY id DESC") fun observe(clientId:Long,year:String):Flow<List<Income>>; @Insert suspend fun insert(item:Income):Long }
@Dao interface ExpenseDao { @Query("SELECT * FROM expenses ORDER BY id DESC") fun observeAll():Flow<List<Expense>>
    @Query("SELECT * FROM expenses") suspend fun all():List<Expense>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun insertAll(items:List<Expense>); @Query("SELECT * FROM expenses WHERE clientId=:clientId AND year=:year ORDER BY id DESC") suspend fun forCalculation(clientId:Long,year:String):List<Expense>; @Insert suspend fun insert(item:Expense):Long; @Delete suspend fun delete(item:Expense); @Query("SELECT COUNT(*) FROM expenses") fun count():Flow<Int> }
@Dao interface TaxCaseDao { @Query("SELECT * FROM tax_cases ORDER BY id DESC") fun observeAll():Flow<List<TaxCase>>
    @Query("SELECT * FROM tax_cases") suspend fun all():List<TaxCase>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun insertAll(items:List<TaxCase>); @Insert suspend fun insert(item:TaxCase):Long; @Delete suspend fun delete(item:TaxCase); @Query("SELECT COUNT(*) FROM tax_cases") fun count():Flow<Int> }
@Dao interface IntaDao { @Query("SELECT * FROM inta_codes ORDER BY year DESC,title") fun observeAll():Flow<List<IntaCode>>
    @Query("SELECT * FROM inta_codes") suspend fun all():List<IntaCode>; @Query("SELECT * FROM inta_codes WHERE year=:year AND (title LIKE '%'||:q||'%' OR code LIKE '%'||:q||'%') ORDER BY title") suspend fun search(year:String,q:String):List<IntaCode>; @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAll(items:List<IntaCode>); @Query("DELETE FROM inta_codes") suspend fun clear() }
@Dao interface RuleDao { @Query("SELECT * FROM tax_rules ORDER BY reference") fun observeAll():Flow<List<TaxRule>>
    @Query("SELECT * FROM tax_rules") suspend fun all():List<TaxRule>; @Query("SELECT * FROM tax_rules WHERE (title LIKE '%'||:q||'%' OR reference LIKE '%'||:q||'%' OR text LIKE '%'||:q||'%' OR relatedTopics LIKE '%'||:q||'%') ORDER BY reference") suspend fun search(q:String):List<TaxRule>; @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAll(items:List<TaxRule>) }
@Dao interface CircularDao { @Query("SELECT * FROM circulars ORDER BY issueDate DESC") fun observeAll():Flow<List<Circular>>; @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAll(items:List<Circular>) }
@Dao interface JudgmentDao { @Query("SELECT * FROM judgments ORDER BY issueDate DESC") fun observeAll():Flow<List<Judgment>>; @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAll(items:List<Judgment>) }
@Dao interface DefenseDao { @Query("SELECT * FROM defense_documents WHERE caseId=:caseId ORDER BY id DESC") fun observeForCase(caseId:Long):Flow<List<DefenseDocument>>; @Insert suspend fun insert(item:DefenseDocument):Long }
@Dao interface DeadlineDao { @Query("SELECT * FROM deadlines WHERE status='OPEN' ORDER BY dueDate") fun observeOpen():Flow<List<Deadline>>; @Insert suspend fun insert(item:Deadline):Long }
@Dao interface SourceDocumentDao { @Query("SELECT * FROM source_documents ORDER BY importedAt DESC") fun observeAll():Flow<List<SourceDocument>>; @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAll(items:List<SourceDocument>) }
@Dao interface CalculationDao { @Query("SELECT * FROM calculations ORDER BY createdAt DESC") fun observeAll():Flow<List<Calculation>>; @Insert suspend fun insert(item:Calculation):Long }
@Dao interface SettingsDao { @Query("SELECT * FROM app_settings") suspend fun all():List<AppSettings>; @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(item:AppSettings) }
