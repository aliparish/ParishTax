package com.aliparish.parishtax

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.LayoutDirection.*
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.navigation.compose.*
import com.aliparish.parishtax.data.db.*
import com.aliparish.parishtax.security.SecurityPreferences
import com.aliparish.parishtax.domain.CalculationResult
import com.aliparish.parishtax.domain.ParishTaxViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm by viewModels<ParishTaxViewModel>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ParishTaxTheme { AppGate { ParishTaxApp(vm) } } }
    }
}

@Composable
fun ParishTaxTheme(content:@Composable ()->Unit){
    val light=lightColorScheme(primary=Color(0xFF26364A),secondary=Color(0xFF496B85),surface=Color(0xFFF8FAFC))
    val dark=darkColorScheme(primary=Color(0xFFB7D1E5),secondary=Color(0xFF9DBDD3))
    MaterialTheme(colorScheme=if(isSystemInDarkTheme())dark else light, typography=Typography(bodyMedium=LocalTextStyle.current.copy(fontSize=14.sp)), content=content)
}


@Composable
fun AppGate(content:@Composable ()->Unit){
    val context=LocalContext.current
    val prefs=remember{SecurityPreferences(context)}
    var unlocked by remember{mutableStateOf(!prefs.biometricEnabled && !prefs.hasPin())}
    if(unlocked){content();return}
    LockScreen(prefs,onUnlocked={unlocked=true})
}

@Composable
fun LockScreen(prefs:SecurityPreferences,onUnlocked:()->Unit){
    val context=LocalContext.current
    var pin by remember{mutableStateOf("")}
    var error by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize().padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
        Icon(Icons.Default.Lock,null,modifier=Modifier.size(56.dp)); Text("ParishTax قفل است",fontSize=24.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(12.dp))
        if(prefs.hasPin()){Field("PIN",pin){pin=it.take(8)};Button(onClick={if(prefs.verifyPin(pin))onUnlocked() else error="PIN نادرست است"},modifier=Modifier.fillMaxWidth()){Text("ورود")}}
        if(prefs.biometricEnabled){Spacer(Modifier.height(8.dp));Button(onClick={
            val activity=context as? ComponentActivity
            if(activity==null){error="امکان احراز هویت وجود ندارد"} else {
                val executor=ContextCompat.getMainExecutor(context)
                BiometricPrompt(activity,executor,object:BiometricPrompt.AuthenticationCallback(){override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult){onUnlocked()}}).authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("ورود به ParishTax").setSubtitle("احراز هویت برای دسترسی به اطلاعات مالیاتی").setNegativeButtonText("انصراف").build())
            }
        },modifier=Modifier.fillMaxWidth()){Text("ورود با اثر انگشت / بیومتریک")}}
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
    }
}

enum class Screen(val route:String,val title:String){HOME("home","داشبورد"),CLIENTS("clients","مشتری‌ها"),CASES("cases","پرونده‌ها"),CALC("calc","محاسبه مالیات"),EXPENSES("expenses","هزینه‌ها"),LAWS("laws","قوانین و دفاع"),DATABASE("database","بانک اطلاعات"),DEADLINES("deadlines","مهلت‌ها"),SETTINGS("settings","تنظیمات")}

@Composable
fun ParishTaxApp(vm:ParishTaxViewModel){
    val nav=rememberNavController(); val clients by vm.clients.collectAsState(); val expenses by vm.expenses.collectAsState(); val cases by vm.cases.collectAsState(); val rules by vm.rules.collectAsState(); val deadlines by vm.deadlines.collectAsState();
    val current=nav.currentBackStackEntryAsState().value?.destination?.route ?: Screen.HOME.route
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl){
        Scaffold(topBar={TopBar(current){nav.navigate(Screen.SETTINGS.route)}} ,bottomBar={BottomNav(current){nav.navigate(it.route){launchSingleTop=true}}}){pad->
            NavHost(nav,startDestination=Screen.HOME.route,modifier=Modifier.padding(pad)){
                composable(Screen.HOME.route){Dashboard(clients,expenses,cases,rules,deadlines){nav.navigate(it)}}
                composable(Screen.CLIENTS.route){ClientsScreen(clients,vm)}
                composable(Screen.CASES.route){CasesScreen(clients,cases,vm)}
                composable(Screen.CALC.route){CalculatorScreen(clients,vm)}
                composable(Screen.EXPENSES.route){ExpensesScreen(clients,expenses,vm)}
                composable(Screen.LAWS.route){LawsScreen(rules,vm)}
                composable(Screen.DATABASE.route){DatabaseScreen(vm)}
                composable(Screen.DEADLINES.route){DeadlinesScreen(deadlines)}
                composable(Screen.SETTINGS.route){SettingsScreen()}
            }
        }
    }
}

@Composable fun TopBar(route:String,onSettings:()->Unit){Surface(shadowElevation=2.dp){Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){Column{Text("ParishTax",fontSize=20.sp,fontWeight=FontWeight.Bold);Text(Screen.entries.firstOrNull{it.route==route}?.title?:"",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)};IconButton(onClick=onSettings){Icon(Icons.Default.Settings,"تنظیمات")}}}}
@Composable fun BottomNav(current:String,onClick:(Screen)->Unit){NavigationBar{listOf(Screen.HOME,Screen.CLIENTS,Screen.CASES,Screen.CALC,Screen.LAWS).forEach{NavigationBarItem(selected=current==it.route,onClick={onClick(it)},icon={Icon(if(it==Screen.HOME)Icons.Default.Home else if(it==Screen.CLIENTS)Icons.Default.People else if(it==Screen.CASES)Icons.Default.Folder else if(it==Screen.CALC)Icons.Default.Calculate else Icons.Default.Gavel,it.title)},label={Text(it.title,fontSize=10.sp)})}}}

@Composable fun Dashboard(clients:List<Client>,expenses:List<Expense>,cases:List<TaxCase>,rules:List<TaxRule>,deadlines:List<Deadline>,go:(String)->Unit){
    val scroll=rememberScrollState(); Column(Modifier.fillMaxSize().verticalScroll(scroll).padding(16.dp)){Text("مرکز کنترل مالیاتی",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("Offline-first • نسخه 1.0",color=MaterialTheme.colorScheme.onSurfaceVariant);Spacer(Modifier.height(12.dp));
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("مشتری",clients.size.toString());Stat("پرونده",cases.size.toString());Stat("هزینه",expenses.size.toString())}
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("قوانین",rules.size.toString());Stat("مهلت باز",deadlines.size.toString());Stat("دفاع",cases.count{it.stage.contains("اعتراض")}.toString())}
        Section("دسترسی سریع");Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){ActionChip("+ مشتری",Icons.Default.PersonAdd){go(Screen.CLIENTS.route)};ActionChip("+ پرونده",Icons.Default.CreateNewFolder){go(Screen.CASES.route)};ActionChip("محاسبه",Icons.Default.Calculate){go(Screen.CALC.route)};ActionChip("+ هزینه",Icons.Default.ReceiptLong){go(Screen.EXPENSES.route)};ActionChip("جستجوی قانون",Icons.Default.Search){go(Screen.LAWS.route)}}
        Section("کنترل کیفیت داده");Card{Column(Modifier.padding(14.dp)){Text("ParishTax قانون یا INTA را حدس نمی‌زند.",fontWeight=FontWeight.Bold);Text("اگر Rule Version، معافیت، نرخ یا ضریب رسمی سال انتخاب‌شده وارد نشده باشد، محاسبه متوقف و Missing Data نمایش داده می‌شود.",fontSize=13.sp);Text("داده‌های DEMO/SAMPLE از داده رسمی متمایز هستند.",fontSize=13.sp,color=MaterialTheme.colorScheme.error)}}
        Section("پرونده‌های نزدیک به مهلت");if(deadlines.isEmpty())EmptyCard("مهلت بازی ثبت نشده است.") else deadlines.take(3).forEach{Card(Modifier.fillMaxWidth()){Text(it.title,fontWeight=FontWeight.Bold);Text("مهلت: ${it.dueDate}")}}
    }
}
@Composable fun Stat(title:String,value:String){Card(Modifier.weight(1f)){Column(Modifier.padding(12.dp)){Text(title,fontSize=12.sp);Text(value,fontSize=24.sp,fontWeight=FontWeight.Bold)}}}
@Composable fun Section(t:String){Text(t,fontWeight=FontWeight.Bold,fontSize=18.sp,modifier=Modifier.padding(top=18.dp,bottom=8.dp))}
@Composable fun ActionChip(t:String,icon:androidx.compose.ui.graphics.vector.ImageVector,onClick:()->Unit){AssistChip(onClick=onClick,label={Text(t)},leadingIcon={Icon(icon,null)})}
@Composable fun EmptyCard(t:String){Card(Modifier.fillMaxWidth()){Text(t,Modifier.padding(16.dp),color=MaterialTheme.colorScheme.onSurfaceVariant)}}

@Composable fun ClientsScreen(clients:List<Client>,vm:ParishTaxViewModel){var show by remember{mutableStateOf(false)};Column(Modifier.fillMaxSize().padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("مشتری‌ها",fontSize=24.sp,fontWeight=FontWeight.Bold);Button(onClick={show=true}){Icon(Icons.Default.Add,null);Text("مشتری جدید")}};Spacer(Modifier.height(8.dp));if(clients.isEmpty())EmptyCard("هنوز مشتری‌ای ثبت نشده است.") else clients.forEach{c->Card(Modifier.fillMaxWidth().padding(vertical=5.dp)){Row(Modifier.padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth()){Column(Modifier.weight(1f)){Text(c.name,fontWeight=FontWeight.Bold);Text("${c.taxpayerType} • ${c.activity.ifBlank{"فعالیت ثبت نشده"}}",fontSize=12.sp);Text("INTA: ${c.intaCode.ifBlank{"—"}}",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)};IconButton(onClick={vm.deleteClient(c)}){Icon(Icons.Default.Delete,null)}}}}};if(show)ClientDialog({show=false},vm)}

@Composable fun ClientDialog(close:()->Unit,vm:ParishTaxViewModel){var name by remember{mutableStateOf("")};var activity by remember{mutableStateOf("")};var inta by remember{mutableStateOf("")};var national by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")};var year by remember{mutableStateOf("1405")};AlertDialog(onDismissRequest=close,title={Text("ثبت مشتری")},text={Column(Modifier.verticalScroll(rememberScrollState())){Field("نام/عنوان",name){name=it};Field("کد ملی/شناسه ملی",national){national=it};Field("شماره تماس",phone){phone=it};Field("فعالیت",activity){activity=it};Field("کد INTA",inta){inta=it};Field("سال عملکرد",year){year=it};Text("سال‌های بعدی برای همین مشتری به صورت مستقل در TaxYear نگهداری می‌شوند.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}},confirmButton={Button(onClick={if(name.isNotBlank()){vm.addClient(Client(name=name,nationalId=national,phone=phone,activity=activity,intaCode=inta));close()}}){Text("ذخیره")}},dismissButton={TextButton(onClick=close){Text("انصراف")}})}

@Composable
fun CasesScreen(clients: List<Client>, cases: List<TaxCase>, vm: ParishTaxViewModel) {
    var show by remember { mutableStateOf(false) }
    val stages = listOf("ثبت و نام‌نویسی","اظهارنامه","رسیدگی","برگ تشخیص","اعتراض ماده 238","هیأت بدوی","تجدیدنظر","قطعی")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("پرونده‌ها", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Button(onClick = { show = true }) { Text("+ پرونده") }
        }
        Text("ثبت → اظهارنامه → رسیدگی → تشخیص → 238 → هیأت → تجدیدنظر → قطعی", fontSize = 12.sp)
        cases.forEach { c ->
            val client = clients.firstOrNull { it.id == c.clientId }
            Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text(c.title, fontWeight = FontWeight.Bold)
                            Text("${client?.name ?: "مشتری حذف‌شده"} • عملکرد ${c.year}", fontSize = 12.sp)
                        }
                        IconButton(onClick = { vm.deleteCase(c) }) { Icon(Icons.Default.Delete, null) }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(c.stage, fontWeight = FontWeight.SemiBold)
                    val index = (stages.indexOf(c.stage) + 1).coerceAtLeast(1)
                    LinearProgressIndicator(progress = { index / stages.size.toFloat() }, modifier = Modifier.fillMaxWidth())
                    Text("مهلت: ${c.legalDeadline.ifBlank { "ثبت نشده" }}", fontSize = 12.sp)
                }
            }
        }
    }
    if (show) CaseDialog(clients, { show = false }, vm)
}

@Composable fun CaseDialog(clients:List<Client>,close:()->Unit,vm:ParishTaxViewModel){var clientId by remember{mutableLongStateOf(clients.firstOrNull()?.id?:0)};var year by remember{mutableStateOf("1405")};var title by remember{mutableStateOf("")};var issue by remember{mutableStateOf("")};var stage by remember{mutableStateOf("ثبت و نام‌نویسی")};var due by remember{mutableStateOf("")};AlertDialog(onDismissRequest=close,title={Text("پرونده جدید")},text={Column(Modifier.verticalScroll(rememberScrollState())){if(clients.isEmpty())Text("ابتدا مشتری ثبت کنید.") else {Text("مشتری");Dropdown(clients.map{it.id to it.name},clientId){clientId=it};Field("سال عملکرد",year){year=it};Field("عنوان پرونده",title){title=it};Text("مرحله");Dropdown(listOf("ثبت و نام‌نویسی","اظهارنامه","رسیدگی","برگ تشخیص","اعتراض ماده 238","هیأت بدوی","تجدیدنظر","قطعی").mapIndexed{_,x->x.hashCode().toLong() to x},stage.hashCode().toLong()){id->stage=listOf("ثبت و نام‌نویسی","اظهارنامه","رسیدگی","برگ تشخیص","اعتراض ماده 238","هیأت بدوی","تجدیدنظر","قطعی").first{it.hashCode().toLong()==id}};Field("مهلت قانونی",due){due=it};Field("موضوع اختلاف",issue){issue=it}}}},confirmButton={Button(onClick={if(clientId!=0L&&title.isNotBlank()){vm.addCase(TaxCase(clientId=clientId,year=year,title=title,issue=issue,stage=stage,legalDeadline=due));close()}}){Text("ذخیره")}},dismissButton={TextButton(onClick=close){Text("انصراف")}})}

@Composable fun CalculatorScreen(clients:List<Client>,vm:ParishTaxViewModel){var cid by remember{mutableLongStateOf(clients.firstOrNull()?.id?:0)};var year by remember{mutableStateOf("1405")};var mode by remember{mutableStateOf("INTA")};var revenue by remember{mutableStateOf("")};var output by remember{mutableStateOf("سال، Rule Version، معافیت، نرخ و INTA باید برای همان سال در بانک معتبر موجود باشند.")};val scope=rememberCoroutineScope();Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)){Text("ماشین حساب مالیاتی",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("محاسبه بدون حدس قانون",color=MaterialTheme.colorScheme.onSurfaceVariant);Spacer(Modifier.height(10.dp));if(clients.isEmpty())EmptyCard("ابتدا مشتری ثبت کنید.") else {Text("مشتری");Dropdown(clients.map{it.id to it.name},cid){cid=it};Field("سال عملکرد",year){year=it};Text("روش محاسبه");Dropdown(listOf("INTA" to "نسبت سود فعالیت / INTA","ACTUAL" to "درآمد واقعی و هزینه‌های مستند"),mode){mode=it};Field("درآمد/فروش سالانه (تومان)",revenue){revenue=it.filter(Char::isDigit)};Button(onClick={scope.launch{val r=vm.calculate(cid,year,mode,revenue.toLongOrNull()?:0);output=when(r){is CalculationResult.Success->"مشمول: ${r.result.taxable} تومان\nمالیات: ${r.result.tax} تومان\nRule Version: ${r.result.ruleVersion}";is CalculationResult.MissingData->"⚠️ ${r.message}"}}},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Calculate,null);Text("محاسبه")};Card{Text(output,Modifier.padding(14.dp))}}}

@Composable fun ExpensesScreen(clients:List<Client>,expenses:List<Expense>,vm:ParishTaxViewModel){var show by remember{mutableStateOf(false)};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("هزینه‌ها",fontSize=24.sp,fontWeight=FontWeight.Bold);Button(onClick={show=true}){Text("+ هزینه")}};Text("ثبت هزینه ≠ پذیرش خودکار. وضعیت سند و ارتباط با درآمد باید بررسی شود.",fontSize=12.sp);expenses.forEach{e->Card(Modifier.fillMaxWidth().padding(vertical=5.dp)){Row(Modifier.padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth()){Column(Modifier.weight(1f)){Text("${e.category} • ${e.amount}",fontWeight=FontWeight.Bold);Text("${clients.firstOrNull{it.id==e.clientId}?.name?:"—"} • ${e.year}",fontSize=12.sp);Text("مدرک: ${e.documentationStatus} • وضعیت: ${e.acceptedStatus}",fontSize=12.sp)};IconButton(onClick={vm.deleteExpense(e)}){Icon(Icons.Default.Delete,null)}}}}}};if(show)ExpenseDialog(clients,{show=false},vm)}
@Composable fun ExpenseDialog(clients:List<Client>,close:()->Unit,vm:ParishTaxViewModel){var cid by remember{mutableLongStateOf(clients.firstOrNull()?.id?:0)};var year by remember{mutableStateOf("1405")};var cat by remember{mutableStateOf("اجاره")};var amount by remember{mutableStateOf("")};var doc by remember{mutableStateOf("UNKNOWN")};var accepted by remember{mutableStateOf("REVIEW")};AlertDialog(onDismissRequest=close,title={Text("ثبت هزینه")},text={Column(Modifier.verticalScroll(rememberScrollState())){if(clients.isNotEmpty()){Text("مشتری");Dropdown(clients.map{it.id to it.name},cid){cid=it}};Field("سال عملکرد",year){year=it};Field("نوع هزینه",cat){cat=it};Field("مبلغ (تومان)",amount){amount=it.filter(Char::isDigit)};Text("وضعیت مستندات");Dropdown(listOf("UNKNOWN" to "نامشخص","DOCUMENTED" to "مستند","MISSING" to "فاقد مدرک"),doc){doc=it};Text("وضعیت پذیرش اولیه");Dropdown(listOf("REVIEW" to "نیازمند بررسی","ACCEPTED" to "قابل قبول","REJECTED" to "فعلاً ردشده"),accepted){accepted=it}}},confirmButton={Button(onClick={if(cid!=0L&&amount.isNotBlank()){vm.addExpense(Expense(clientId=cid,year=year,category=cat,amount=amount.toLong(),documentationStatus=doc,acceptedStatus=accepted));close()}}){Text("ذخیره")}},dismissButton={TextButton(onClick=close){Text("انصراف")}})}

@Composable fun LawsScreen(rules:List<TaxRule>,vm:ParishTaxViewModel){var q by remember{mutableStateOf("")};var caseText by remember{mutableStateOf("")};var results by remember{mutableStateOf<List<TaxRule>>(emptyList())};val scope=rememberCoroutineScope();Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)){Text("قوانین و دستیار دفاع",fontSize=24.sp,fontWeight=FontWeight.Bold);Field("جستجوی قانون / موضوع",q){q=it;scope.launch{results=if(it.isBlank())rules.take(20) else vm.searchRules(it)}};results.ifEmpty{rules.take(20)}.forEach{r->RuleCard(r)};Section("تحلیل پرونده");Field("شرح مسئله",caseText){caseText=it};Button(onClick={scope.launch{results=vm.searchRules(caseText)}}){Text("پیدا کردن منابع مرتبط")};if(caseText.isNotBlank()){Card{Column(Modifier.padding(14.dp)){Text("خروجی دفاعی",fontWeight=FontWeight.Bold);Text("این نسخه فقط منابع موجود در بانک را بازیابی می‌کند. متن دفاعیه نهایی باید با اسناد پرونده و منبع رسمی بررسی شود.");Button(onClick={}){Text("تولید پیش‌نویس اعتراض")}}}}}}
@Composable fun RuleCard(r:TaxRule){Card(Modifier.fillMaxWidth().padding(vertical=5.dp)){Column(Modifier.padding(14.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text(r.reference,fontWeight=FontWeight.Bold);Spacer(Modifier.width(8.dp));AssistChip(onClick={},label={Text(r.status)})};Text(r.title,fontWeight=FontWeight.SemiBold);Text(r.text,fontSize=13.sp);if(r.source.isNotBlank())Text("منبع: ${r.source}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}

@Composable fun DatabaseScreen(vm:ParishTaxViewModel){val inta by vm.inta.collectAsState();val rules by vm.rules.collectAsState();var q by remember{mutableStateOf("")};var year by remember{mutableStateOf("1403")};var lq by remember{mutableStateOf("")};val scope=rememberCoroutineScope();val context=LocalContext.current;var message by remember{mutableStateOf("")};val create=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->if(uri!=null)scope.launch{context.contentResolver.openOutputStream(uri)?.use{it.write(vm.exportJson().toByteArray())};message="پشتیبان ایجاد شد."}};val open=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)scope.launch{try{val text=context.contentResolver.openInputStream(uri)!!.bufferedReader().readText();vm.importJson(text);message="بازیابی انجام شد."}catch(e:Exception){message="بازیابی ناموفق: ${e.message}"}}};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)){Text("بانک اطلاعات",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("INTA و قوانین بدون Source معتبر، رسمی تلقی نمی‌شوند.",fontSize=12.sp,color=MaterialTheme.colorScheme.error);Section("INTA");Field("جستجو",q){q=it};Text("سال");Dropdown(listOf("1403" to "1403","1404" to "1404","1405" to "1405"),year){year=it};inta.filter{it.year==year&&(q.isBlank()||it.title.contains(q)||it.code.contains(q))}.forEach{RuleCard(TaxRule(reference=it.code,title=it.title,applicableTaxYears=it.year,text="ضریب سود: ${it.profitPercent?:"ثبت نشده"}%",status=it.status,source=it.source,isDemo=it.isDemo))};Section("قوانین");Field("جستجو",lq){lq=it};rules.filter{lq.isBlank()||it.title.contains(lq)||it.reference.contains(lq)||it.text.contains(lq)}.forEach{RuleCard(it)};Section("پشتیبان");Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={create.launch("ParishTax_backup.json")}){Text("خروجی JSON")};Button(onClick={open.launch(arrayOf("application/json"))}){Text("بازیابی JSON")}};if(message.isNotBlank())Text(message,color=MaterialTheme.colorScheme.primary)}}

@Composable fun DeadlinesScreen(deadlines:List<Deadline>){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)){Text("مهلت‌ها",fontSize=24.sp,fontWeight=FontWeight.Bold);if(deadlines.isEmpty())EmptyCard("مهلت فعالی ثبت نشده است.") else deadlines.forEach{Card(Modifier.fillMaxWidth().padding(vertical=5.dp)){Text(it.title,fontWeight=FontWeight.Bold);Text(it.dueDate);Text(it.notes,fontSize=12.sp)}}}}
@Composable fun SettingsScreen(){
    val context=LocalContext.current; val prefs=remember{SecurityPreferences(context)}; var biometric by remember{mutableStateOf(prefs.biometricEnabled)}; var showPin by remember{mutableStateOf(false)}; var pin by remember{mutableStateOf("")}; var status by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)){
        Text("تنظیمات",fontSize=24.sp,fontWeight=FontWeight.Bold);
        Card{Column(Modifier.padding(14.dp)){Text("امنیت",fontWeight=FontWeight.Bold);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("قفل بیومتریک");Switch(checked=biometric,onCheckedChange={v->biometric=v;prefs.biometricEnabled=v})};Button(onClick={showPin=true}){Text(if(prefs.hasPin())"تغییر PIN" else "تنظیم PIN")};Text("پایگاه داده با SQLCipher رمزنگاری می‌شود و کلید آن در Android Keystore محافظت می‌شود.",fontSize=12.sp)}};
        Card(Modifier.padding(top=10.dp)){Column(Modifier.padding(14.dp)){Text("AI Tax Assistant",fontWeight=FontWeight.Bold);Text("اتصال‌دهنده AI جدا از موتور قوانین است؛ تا وقتی Provider/API Key تنظیم نشده، دستیار فقط منابع محلی را بازیابی می‌کند.",fontSize=12.sp);TextButton(onClick={status="Provider هنوز پیکربندی نشده است."}){Text("بررسی اتصال")};Text(status,fontSize=12.sp)}};
        Card(Modifier.padding(top=10.dp)){Column(Modifier.padding(14.dp)){Text("نسخه",fontWeight=FontWeight.Bold);Text("ParishTax 1.0.0 • schema 1");Text("Application ID: com.aliparish.parishtax",fontSize=12.sp)}}
    }
    if(showPin)AlertDialog(onDismissRequest={showPin=false},title={Text("تنظیم PIN")},text={Field("PIN حداقل 4 رقم",pin){pin=it.filter(Char::isDigit).take(8)}},confirmButton={Button(onClick={if(pin.length>=4){prefs.setPin(pin);showPin=false;status="PIN ذخیره شد."}}){Text("ذخیره")}},dismissButton={TextButton(onClick={showPin=false}){Text("انصراف")}})
}

@Composable fun Field(label:String,value:String,onChange:(String)->Unit){OutlinedTextField(value=value,onValueChange=onChange,label={Text(label)},modifier=Modifier.fillMaxWidth().padding(vertical=4.dp),singleLine=false)}
@Composable fun <T> Dropdown(items:List<Pair<T,String>>,selected:T,onSelect:(T)->Unit){var open by remember{mutableStateOf(false)};Box{OutlinedButton(onClick={open=true},modifier=Modifier.fillMaxWidth()){Text(items.firstOrNull{it.first==selected}?.second?:"انتخاب")};DropdownMenu(expanded=open,onDismissRequest={open=false}){items.forEach{DropdownMenuItem(text={Text(it.second)},onClick={open=false;onSelect(it.first)})}}}}
