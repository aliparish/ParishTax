package com.aliparish.parishtax.domain

import com.aliparish.parishtax.data.db.Expense
import com.aliparish.parishtax.data.db.IntaCode

sealed interface CalculationResult {
    data class Success(val result: TaxResult): CalculationResult
    data class MissingData(val message: String): CalculationResult
}
data class TaxResult(val revenue:Long,val profit:Long,val acceptedExpenses:Long,val exemption:Long,val taxable:Long,val tax:Long,val ruleVersion:String)

class TaxEngine {
    fun calculate(
        year:String,
        revenue:Long,
        mode:String,
        inta:IntaCode?,
        expenses:List<Expense>,
        exemption:Long?,
        ruleVersion:String?,
        taxRatePercent: Double?
    ):CalculationResult {
        if (exemption == null) return CalculationResult.MissingData("معافیت ماده ۱۰۱ برای سال $year در بانک معتبر موجود نیست.")
        if (ruleVersion.isNullOrBlank()) return CalculationResult.MissingData("Rule Version معتبر برای سال $year موجود نیست.")
        val accepted = if (mode == "ACTUAL") expenses.filter { it.acceptedStatus == "ACCEPTED" }.sumOf { it.amount } else 0L
        val profit = when (mode) {
            "INTA" -> {
                val p = inta?.profitPercent ?: return CalculationResult.MissingData("کد INTA معتبر برای سال $year و فعالیت انتخاب‌شده پیدا نشد؛ محاسبه متوقف شد.")
                (revenue * p / 100.0).toLong()
            }
            "ACTUAL" -> (revenue - accepted).coerceAtLeast(0)
            else -> return CalculationResult.MissingData("روش محاسبه ناشناخته است.")
        }
        val taxable = (profit - exemption).coerceAtLeast(0)
        val rate = taxRatePercent ?: return CalculationResult.MissingData("نرخ مالیات سال $year در بانک قواعد وارد نشده است؛ بنابراین مبلغ مالیات محاسبه نمی‌شود.")
        val tax = (taxable * rate / 100.0).toLong()
        return CalculationResult.Success(TaxResult(revenue, profit, accepted, exemption, taxable, tax, ruleVersion))
    }
}
