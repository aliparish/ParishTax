package com.aliparish.parishtax.importer

import com.aliparish.parishtax.data.db.IntaCode
import com.aliparish.parishtax.data.db.TaxRule

/**
 * Official-data ingestion boundary.
 * Flow: Import -> Parse -> Validate -> Deduplicate -> Version -> Review -> Publish.
 * The app deliberately does not auto-publish unverified records.
 */
class ImportPipeline {
    enum class Stage { IMPORT, PARSE, VALIDATE, DEDUPLICATE, VERSION, REVIEW, PUBLISH }
    data class Report(val imported:Int,val accepted:Int,val rejected:Int,val messages:List<String>)

    fun validateInta(records:List<IntaCode>):Report {
        val messages=mutableListOf<String>(); var rejected=0
        val accepted=records.distinctBy{it.code to it.year}.filter{
            val ok=it.code.isNotBlank()&&it.title.isNotBlank()&&it.year.matches(Regex("14\\d{2}"))&&it.status=="VERIFIED"&&it.source.isNotBlank()
            if(!ok){rejected++;messages += "INTA ${it.code}/${it.year}: missing source/year/title or not VERIFIED"}
            ok
        }
        return Report(records.size,accepted.size,rejected,messages)
    }
    fun validateRules(records:List<TaxRule>):Report {
        val messages=mutableListOf<String>(); var rejected=0
        val accepted=records.distinctBy{listOf(it.reference,it.version,it.effectiveFrom)}.filter{
            val ok=it.reference.isNotBlank()&&it.title.isNotBlank()&&it.text.isNotBlank()&&it.source.isNotBlank()&&it.version.isNotBlank()
            if(!ok){rejected++;messages += "Rule ${it.reference}: incomplete source/version/text"}
            ok
        }
        return Report(records.size,accepted.size,rejected,messages)
    }
}
