package com.aliparish.parishtax

import com.aliparish.parishtax.data.db.Expense
import com.aliparish.parishtax.data.db.IntaCode
import com.aliparish.parishtax.domain.CalculationResult
import com.aliparish.parishtax.domain.TaxEngine
import org.junit.Assert.*
import org.junit.Test

class TaxEngineTest {
    private val engine=TaxEngine()
    private val inta=IntaCode(code="3200030",title="Demo",year="1403",profitPercent=25.0,status="DEMO",isDemo=true)
    @Test fun blocksWhenExemptionMissing(){
        val r=engine.calculate("1403",100_000,"INTA",inta,emptyList(),null,"1403.1",15.0)
        assertTrue(r is CalculationResult.MissingData)
    }
    @Test fun blocksWhenRateMissing(){
        val r=engine.calculate("1403",100_000,"INTA",inta,emptyList(),10_000,"1403.1",null)
        assertTrue(r is CalculationResult.MissingData)
    }
    @Test fun usesOnlyAcceptedExpensesInActualMode(){
        val expenses=listOf(
            Expense(clientId=1,year="1403",category="اجاره",amount=30_000,acceptedStatus="ACCEPTED"),
            Expense(clientId=1,year="1403",category="فاقد مدرک",amount=50_000,acceptedStatus="REJECTED")
        )
        val r=engine.calculate("1403",100_000,"ACTUAL",null,expenses,10_000,"1403.1",15.0)
        assertTrue(r is CalculationResult.Success)
        assertEquals(60_000,(r as CalculationResult.Success).result.taxable)
    }
    @Test fun intaModeDoesNotSubtractActualExpenses(){
        val expenses=listOf(Expense(clientId=1,year="1403",category="اجاره",amount=90_000,acceptedStatus="ACCEPTED"))
        val r=engine.calculate("1403",100_000,"INTA",inta,expenses,10_000,"1403.1",15.0)
        assertTrue(r is CalculationResult.Success)
        assertEquals(15_000,(r as CalculationResult.Success).result.taxable)
    }
}
